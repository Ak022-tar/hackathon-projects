import time
import PyPDF2
import openai
from tkinter import Tk
from tkinter.filedialog import askopenfilename
import webbrowser

# Set up your OpenAI API key
openai.api_key = 'api key'


# Function to extract text from PDF
def extract_text_from_pdf(pdf_file, num_pages):
    text = ""
    with open(pdf_file, 'rb') as file:
        reader = PyPDF2.PdfReader(file)
        total_pages = len(reader.pages)
        pages_to_read = min(num_pages, total_pages)

        for page_num in range(pages_to_read):
            page = reader.pages[page_num]
            text += page.extract_text()

    return text  # return full extracted text


# Function to implement the 25-minute Pomodoro timer
def pomodoro_timer(duration_minutes=25):
    total_seconds = duration_minutes * 60
    for remaining in range(total_seconds, 0, -1):
        mins, secs = divmod(remaining, 60)
        print(f"Time left: {mins:02d}:{secs:02d}", end='\r')
        time.sleep(1)  # Wait for 1 second


# Function to generate quiz questions using GPT and calculate score
def generate_ai_quiz(content):
    prompt = (f"Based on the following content, generate 10 multiple-choice quiz questions. "
              f"The format should be:\n"
              f"Q: [Question]\n"
              f"Options:\n"
              f"a) [Option A]\n"
              f"b) [Option B]\n"
              f"c) [Option C]\n"
              f"d) [Option D]\n\n"
              f"Also provide the correct answer for each question.\n\n"
              f"Content:\n{content[:2000]}")  # Limit the text to avoid very large prompts

    try:
        response = openai.Completion.create(
            engine="gpt-3.5-turbo",  # Use GPT-3 or any other engine
            prompt=prompt,
            max_tokens=1500,
            n=1,
            stop=None,
            temperature=0.7
        )
        quiz_content = response.choices[0].text.strip()
        quiz_data = quiz_content.split("\n\n")
        questions = [q for q in quiz_data if "Q:" in q]
        correct_answers = [q.split("Answer:")[1].strip().lower() for q in quiz_data if "Answer:" in q]

        # Asking the user to answer the questions
        score = 0
        print("\n--- AI Generated Quiz ---\n")
        for idx, question in enumerate(questions):
            print(question)
            user_answer = input("Your answer (a/b/c/d): ").strip().lower()
            if user_answer == correct_answers[idx]:
                score += 1

        # Calculate percentage score
        total_questions = len(questions)
        score_percentage = (score / total_questions) * 100
        print(f"\nYour score: {score}/{total_questions} ({score_percentage:.2f}%)")

        # Redirect based on the score
        if score_percentage <= 50:
            print("Redirecting to tic-tac-toe game...")
            webbrowser.open("tic.html")  # Redirect to tic.html
        else:
            print("Redirecting to flappy bird game...")
            webbrowser.open("flappy.html")  # Redirect to flappy.html

    except Exception as e:
        print(f"Error generating quiz: {e}")


# Function to get a PDF file from user using tkinter
def get_pdf_file():
    # Initialize Tkinter window and hide it
    root = Tk()
    root.withdraw()  # Hide the root window
    root.wm_attributes('-topmost', 1)  # Force focus on the file dialog

    # Ask user to select a PDF file
    pdf_file_path = askopenfilename(
        title="Select a PDF file",
        filetypes=[("PDF files", "*.pdf")],
        defaultextension=".pdf"
    )

    if pdf_file_path:
        print(f"Selected PDF: {pdf_file_path}")
        return pdf_file_path
    else:
        print("No file selected. Exiting.")
        exit()  # Exit if no file is selected


# Main function to run the Pomodoro session and quiz
def run_pomodoro_with_quiz():
    # Step 1: Get PDF file from user using file dialog
    pdf_file = get_pdf_file()

    try:
        # Step 2: Pomodoro session
        print("\nStarting 25-minute reading session...\n")
        pomodoro_timer(25)
        print("\n25 minutes are up!")

        # Step 3: Ask the user if they want to attend a quiz
        choice = input("\nDo you want to take a quiz based on what you read? (Y/N): ").strip().lower()
        if choice == 'y':
            # Step 4: Extract text from PDF and generate quiz
            num_pages_read = int(input("Enter the number of pages read: "))
            content = extract_text_from_pdf(pdf_file, num_pages_read)
            generate_ai_quiz(content)
        else:
            print("\nQuiz skipped. Hope you had a good reading session!")

    except Exception as e:
        print(f"Error: {e}")


run_pomodoro_with_quiz()
